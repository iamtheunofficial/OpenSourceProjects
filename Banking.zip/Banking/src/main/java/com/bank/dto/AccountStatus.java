package com.bank.dto;

public class AccountStatus {

	private String msg;
	private Long accountNumber;
	private Long customerId;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNo(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	public AccountStatus(String msg, Long accountNo) {
		super();
		this.msg = msg;
		this.accountNumber = accountNo;
	}
	public AccountStatus(String msg, Long accountNo, Long customerId) {
		super();
		this.msg = msg;
		this.accountNumber = accountNo;
		this.customerId = customerId;
	}
	public AccountStatus() {
		// TODO Auto-generated constructor stub
	}
	
	
}
