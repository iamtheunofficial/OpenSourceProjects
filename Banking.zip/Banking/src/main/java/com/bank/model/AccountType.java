package com.bank.model;

public enum AccountType {

	SAVING,
	CURRENT,
	FIXEDACCOUNT,
	RECURRINGDEPOSIT
	
}
