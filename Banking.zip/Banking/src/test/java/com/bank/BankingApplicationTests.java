package com.bank;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

class BankingApplicationTests {

	
	
	
}
